export const VIETQR_CONFIG = {
  ADMIN_ACCOUNT: {
    bank_code: '970405',
    account_number: '1606205413597',
    beneficiary_name: 'VO PHAM TRI THIEN',
  },
}
